<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Colegio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #e0eafc, #cfdef3);
            min-height: 100vh;
        }
        .card-hover:hover {
            transform: scale(1.05);
            transition: transform 0.2s;
            cursor: pointer;
        }
        .dashboard-title {
            text-shadow: 1px 1px 2px #ccc;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="text-center mb-5 dashboard-title text-primary">📘 Panel de Administración del Colegio</h2>
    <div class="row g-4 justify-content-center">

        <div class="col-sm-6 col-md-4 col-lg-3">
            <a href="views/estudiantes.php" class="text-decoration-none">
                <div class="card shadow text-center p-4 card-hover bg-light">
                    <i class="bi bi-people-fill display-3 text-primary"></i>
                    <h5 class="mt-3">Estudiantes</h5>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-md-4 col-lg-3">
            <a href="views/profesores.php" class="text-decoration-none">
                <div class="card shadow text-center p-4 card-hover bg-light">
                    <i class="bi bi-person-badge-fill display-3 text-success"></i>
                    <h5 class="mt-3">Profesores</h5>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-md-4 col-lg-3">
            <a href="views/cursos.php" class="text-decoration-none">
                <div class="card shadow text-center p-4 card-hover bg-light">
                    <i class="bi bi-journal-bookmark-fill display-3 text-warning"></i>
                    <h5 class="mt-3">Cursos</h5>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-md-4 col-lg-3">
            <a href="views/notas.php" class="text-decoration-none">
                <div class="card shadow text-center p-4 card-hover bg-light">
                    <i class="bi bi-pencil-square display-3 text-danger"></i>
                    <h5 class="mt-3">Notas</h5>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-md-4 col-lg-3">
            <a href="views/inscripciones.php" class="text-decoration-none">
                <div class="card shadow text-center p-4 card-hover bg-light">
                    <i class="bi bi-clipboard-check display-3 text-info"></i>
                    <h5 class="mt-3">Inscripciones</h5>
                </div>
            </a>
        </div>

        <div class="col-sm-6 col-md-4 col-lg-3">
            <a href="logout.php" class="text-decoration-none">
                <div class="card shadow text-center p-4 card-hover bg-light">
                    <i class="bi bi-box-arrow-right display-3 text-secondary"></i>
                    <h5 class="mt-3">Cerrar Sesión</h5>
                </div>
            </a>
        </div>
    </div>

    <!-- SOLO PARA ADMINISTRATIVO -->
    <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'Administrativo'): ?>
        <div class="container mt-5">
            <h4 class="text-center text-danger">👮 Gestión de Usuarios Bloqueados</h4>

            <?php
            require_once 'includes/db.php';
            $stmt = $pdo->query("SELECT id_usuario, nombre, apellido, correo, estado FROM usuarios WHERE estado = 'Bloqueado'");
            $bloqueados = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (count($bloqueados) > 0): ?>
                <table class="table table-bordered table-hover mt-3 bg-white">
                    <thead class="table-danger">
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Estado</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bloqueados as $usuario): ?>
                            <tr>
                                <td><?= $usuario['id_usuario'] ?></td>
                                <td><?= $usuario['nombre'] . ' ' . $usuario['apellido'] ?></td>
                                <td><?= $usuario['correo'] ?></td>
                                <td><?= $usuario['estado'] ?></td>
                                <td>
                                    <form method="post" action="desbloquear_usuario.php" onsubmit="return confirm('¿Estás seguro de desbloquear este usuario?');">
                                        <input type="hidden" name="id_usuario" value="<?= $usuario['id_usuario'] ?>">
                                        <button type="submit" class="btn btn-success btn-sm">Desbloquear</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-center mt-4">No hay usuarios bloqueados actualmente.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</div>

</body>
</html>
