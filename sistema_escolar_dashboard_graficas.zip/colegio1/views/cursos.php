
<?php
require_once '../includes/db.php';
session_start();

// Crear curso
if (isset($_POST['accion']) && $_POST['accion'] === 'crear') {
    $nombre = $_POST['nombre'];
    $programa = $_POST['programa'];

    $stmt = $pdo->prepare("INSERT INTO cursos (nombre_curso, id_programa) VALUES (?, ?)");
    $stmt->execute([$nombre, $programa]);
    header("Location: cursos.php");
    exit;
}

// Editar curso
if (isset($_POST['accion']) && $_POST['accion'] === 'editar') {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $programa = $_POST['programa'];

    $stmt = $pdo->prepare("UPDATE cursos SET nombre_curso=?, id_programa=? WHERE id_curso=?");
    $stmt->execute([$nombre, $programa, $id]);
    header("Location: cursos.php");
    exit;
}

// Eliminar curso
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $stmt = $pdo->prepare("DELETE FROM cursos WHERE id_curso=?");
    $stmt->execute([$id]);
    header("Location: cursos.php");
    exit;
}

// Listar cursos y programas
$cursos = $pdo->query("SELECT * FROM cursos")->fetchAll(PDO::FETCH_ASSOC);
$programas = $pdo->query("SELECT * FROM programas")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cursos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-4">📘 Cursos</h2>

    <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#modalCrear">➕ Nuevo Curso</button>

    <table class="table table-striped table-bordered bg-white shadow">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre del Curso</th>
                <th>ID Programa</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cursos as $c): ?>
                <tr>
                    <td><?= $c['id_curso'] ?></td>
                    <td><?= $c['nombre_curso'] ?></td>
                    <td><?= $c['id_programa'] ?></td>
                    <td>
                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#modalEditar<?= $c['id_curso'] ?>">✏️</button>
                        <a href="?eliminar=<?= $c['id_curso'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar curso?')">🗑️</a>
                    </td>
                </tr>

                <!-- Modal Editar Curso -->
                <div class="modal fade" id="modalEditar<?= $c['id_curso'] ?>" tabindex="-1">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <form method="POST">
                          <div class="modal-header"><h5 class="modal-title">Editar Curso</h5></div>
                          <div class="modal-body">
                              <input type="hidden" name="accion" value="editar">
                              <input type="hidden" name="id" value="<?= $c['id_curso'] ?>">
                              <div class="mb-2"><label>Nombre</label><input type="text" name="nombre" class="form-control" value="<?= $c['nombre_curso'] ?>"></div>
                              <div class="mb-2"><label>Programa</label>
                                  <select name="programa" class="form-select">
                                      <?php foreach ($programas as $p): ?>
                                          <option value="<?= $p['id_programa'] ?>" <?= $p['id_programa'] == $c['id_programa'] ? 'selected' : '' ?>><?= $p['nombre_programa'] ?></option>
                                      <?php endforeach; ?>
                                  </select>
                              </div>
                          </div>
                          <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Guardar</button>
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                          </div>
                      </form>
                    </div>
                  </div>
                </div>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal Crear Curso -->
<div class="modal fade" id="modalCrear" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
          <div class="modal-header"><h5 class="modal-title">Nuevo Curso</h5></div>
          <div class="modal-body">
              <input type="hidden" name="accion" value="crear">
              <div class="mb-2"><label>Nombre</label><input type="text" name="nombre" class="form-control" required></div>
              <div class="mb-2"><label>Programa</label>
                  <select name="programa" class="form-select">
                      <?php foreach ($programas as $p): ?>
                          <option value="<?= $p['id_programa'] ?>"><?= $p['nombre_programa'] ?></option>
                      <?php endforeach; ?>
                  </select>
              </div>
          </div>
          <div class="modal-footer">
              <button type="submit" class="btn btn-success">Guardar</button>
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
