
<?php
require_once '../includes/db.php';
session_start();

// Crear nota
if (isset($_POST['accion']) && $_POST['accion'] === 'crear') {
    $usuario = $_POST['usuario'];
    $curso = $_POST['curso'];
    $nota = $_POST['nota'];

    $stmt = $pdo->prepare("INSERT INTO notas (id_usuario, id_curso, nota) VALUES (?, ?, ?)");
    $stmt->execute([$usuario, $curso, $nota]);
    header("Location: notas.php");
    exit;
}

// Editar nota
if (isset($_POST['accion']) && $_POST['accion'] === 'editar') {
    $id = $_POST['id'];
    $nota = $_POST['nota'];

    $stmt = $pdo->prepare("UPDATE notas SET nota=? WHERE id_nota=?");
    $stmt->execute([$nota, $id]);
    header("Location: notas.php");
    exit;
}

// Eliminar nota
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $stmt = $pdo->prepare("DELETE FROM notas WHERE id_nota=?");
    $stmt->execute([$id]);
    header("Location: notas.php");
    exit;
}

// Listar notas, estudiantes y cursos
$notas = $pdo->query("SELECT n.id_nota, u.nombre, u.apellido, c.nombre_curso, n.nota FROM notas n
                      JOIN usuarios u ON n.id_usuario = u.id_usuario
                      JOIN cursos c ON n.id_curso = c.id_curso")->fetchAll(PDO::FETCH_ASSOC);

$estudiantes = $pdo->query("SELECT * FROM usuarios WHERE tipo = 'Estudiante'")->fetchAll(PDO::FETCH_ASSOC);
$cursos = $pdo->query("SELECT * FROM cursos")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Notas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-4">📝 Notas</h2>

    <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#modalCrear">➕ Nueva Nota</button>

    <table class="table table-striped table-bordered bg-white shadow">
        <thead>
            <tr>
                <th>ID</th>
                <th>Estudiante</th>
                <th>Curso</th>
                <th>Nota</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($notas as $n): ?>
                <tr>
                    <td><?= $n['id_nota'] ?></td>
                    <td><?= $n['nombre'] . ' ' . $n['apellido'] ?></td>
                    <td><?= $n['nombre_curso'] ?></td>
                    <td><?= $n['nota'] ?></td>
                    <td>
                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#modalEditar<?= $n['id_nota'] ?>">✏️</button>
                        <a href="?eliminar=<?= $n['id_nota'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar nota?')">🗑️</a>
                    </td>
                </tr>

                <!-- Modal Editar Nota -->
                <div class="modal fade" id="modalEditar<?= $n['id_nota'] ?>" tabindex="-1">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <form method="POST">
                          <div class="modal-header"><h5 class="modal-title">Editar Nota</h5></div>
                          <div class="modal-body">
                              <input type="hidden" name="accion" value="editar">
                              <input type="hidden" name="id" value="<?= $n['id_nota'] ?>">
                              <div class="mb-2"><label>Nota</label><input type="number" name="nota" class="form-control" step="0.01" min="0" max="100" value="<?= $n['nota'] ?>"></div>
                          </div>
                          <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Guardar</button>
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                          </div>
                      </form>
                    </div>
                  </div>
                </div>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal Crear Nota -->
<div class="modal fade" id="modalCrear" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
          <div class="modal-header"><h5 class="modal-title">Nueva Nota</h5></div>
          <div class="modal-body">
              <input type="hidden" name="accion" value="crear">
              <div class="mb-2"><label>Estudiante</label>
                  <select name="usuario" class="form-select" required>
                      <?php foreach ($estudiantes as $e): ?>
                          <option value="<?= $e['id_usuario'] ?>"><?= $e['nombre'] . ' ' . $e['apellido'] ?></option>
                      <?php endforeach; ?>
                  </select>
              </div>
              <div class="mb-2"><label>Curso</label>
                  <select name="curso" class="form-select" required>
                      <?php foreach ($cursos as $c): ?>
                          <option value="<?= $c['id_curso'] ?>"><?= $c['nombre_curso'] ?></option>
                      <?php endforeach; ?>
                  </select>
              </div>
              <div class="mb-2"><label>Nota</label><input type="number" name="nota" class="form-control" step="0.01" min="0" max="100" required></div>
          </div>
          <div class="modal-footer">
              <button type="submit" class="btn btn-success">Guardar</button>
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
