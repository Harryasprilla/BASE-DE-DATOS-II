
<?php
session_start();
require_once '../includes/db.php';
if (!isset($_SESSION['usuario'])) {
    header('Location: ../login.php');
    exit;
}

$usuario = $_SESSION['usuario'];

// Contadores corregidos (tabla correcta: usuarios)
$total_estudiantes = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE tipo = 'Estudiante'")->fetchColumn();
$total_docentes = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE tipo = 'Docente'")->fetchColumn();
$total_cursos = $pdo->query("SELECT COUNT(*) FROM cursos")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Sistema Escolar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
        }
        .sidebar {
            height: 100vh;
            background-color: #343a40;
            padding-top: 1rem;
        }
        .sidebar a {
            color: white;
            display: block;
            padding: 10px 15px;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .card {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 sidebar">
            <h4 class="text-white text-center">Menú</h4>
            <a href="dashboard.php">🏠 Dashboard</a>
            <a href="estudiantes.php">👨‍🎓 Estudiantes</a>
            <a href="profesores.php">👩‍🏫 Docentes</a>
            <a href="cursos.php">📚 Cursos</a>
            <a href="inscripciones.php">📝 Inscripciones</a>
            <a href="../logout.php">🚪 Cerrar Sesión</a>
        </div>
        <div class="col-md-10 p-4">
            <h2 class="mb-4">Bienvenido, <?= $usuario['nombre'] ?> 👋</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card text-bg-primary">
                        <div class="card-body">
                            <h5 class="card-title">Estudiantes</h5>
                            <p class="card-text fs-3"><?= $total_estudiantes ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-bg-success">
                        <div class="card-body">
                            <h5 class="card-title">Docentes</h5>
                            <p class="card-text fs-3"><?= $total_docentes ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-bg-warning">
                        <div class="card-body">
                            <h5 class="card-title">Cursos</h5>
                            <p class="card-text fs-3"><?= $total_cursos ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
