<?php
session_start();
if (!isset($_SESSION['usuario'])) header("Location: ../index.php");
require_once '../includes/db.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id_usuario = ? AND tipo = 'Estudiante'");
    $stmt->execute([$id]);
}
header("Location: estudiantes.php");
exit;
