<?php
session_start();
if (!isset($_SESSION['usuario'])) header("Location: ../index.php");
require_once '../includes/db.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM cursos WHERE id_curso = ?");
    $stmt->execute([$id]);
}
header("Location: cursos.php");
exit;
