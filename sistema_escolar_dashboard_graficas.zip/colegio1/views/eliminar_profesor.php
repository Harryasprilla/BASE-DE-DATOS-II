<?php
session_start();
if (!isset($_SESSION['usuario'])) header("Location: ../index.php");
require_once '../includes/db.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id_usuario = ? AND tipo = 'Docente'");
    $stmt->execute([$id]);
}
header("Location: profesores.php");
exit;
