<?php
session_start();
if (!isset($_SESSION['usuario'])) header("Location: ../index.php");
require_once '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = $_POST['nombre'];
    $programa = $_POST['programa'];
    
    $stmt = $pdo->prepare("INSERT INTO cursos (nombre_curso, id_programa) VALUES (?, ?)");
    $stmt->execute([$nombre, $programa]);
    
    header("Location: cursos.php");
    exit;
}

$programas = $pdo->query("SELECT * FROM programas")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Curso</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h3>➕ Agregar Nuevo Curso</h3>
    <form method="POST" class="mt-3">
        <div class="mb-3">
            <label>Nombre del Curso</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Programa Asociado</label>
            <select name="programa" class="form-select" required>
                <option value="">Selecciona un programa</option>
                <?php foreach ($programas as $p): ?>
                    <option value="<?= $p['id_programa']; ?>"><?= $p['nombre_programa']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Guardar</button>
        <a href="cursos.php" class="btn btn-secondary">Cancelar</a>
    </form>
</body>
</html>
