<?php
session_start();
if (!isset($_SESSION['usuario'])) header("Location: ../index.php");
require_once '../includes/db.php';

$id = $_GET['id'] ?? null;
if (!$id) header("Location: profesores.php");

$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$id]);
$profesor = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    
    $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ? WHERE id_usuario = ?");
    $stmt->execute([$nombre, $apellido, $correo, $id]);

    header("Location: profesores.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Profesor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h3>✏️ Editar Profesor</h3>
    <form method="POST" class="mt-3">
        <div class="mb-3">
            <label>Nombre</label>
            <input type="text" name="nombre" class="form-control" value="<?= $profesor['nombre']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Apellido</label>
            <input type="text" name="apellido" class="form-control" value="<?= $profesor['apellido']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Correo</label>
            <input type="email" name="correo" class="form-control" value="<?= $profesor['correo']; ?>" required>
        </div>
        <button type="submit" class="btn btn-warning">Actualizar</button>
        <a href="profesores.php" class="btn btn-secondary">Cancelar</a>
    </form>
</body>
</html>
