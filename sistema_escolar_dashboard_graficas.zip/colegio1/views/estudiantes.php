
<?php
require_once '../includes/db.php';
session_start();

// Validar login y tipo de usuario si se requiere aquí

// Crear estudiante
if (isset($_POST['accion']) && $_POST['accion'] === 'crear') {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, tipo, estado) VALUES (?, ?, ?, ?, 'Estudiante', 'Activo')");
    $stmt->execute([$nombre, $apellido, $correo, $password]);
    header("Location: estudiantes.php");
    exit;
}

// Actualizar estudiante
if (isset($_POST['accion']) && $_POST['accion'] === 'editar') {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];

    $stmt = $pdo->prepare("UPDATE usuarios SET nombre=?, apellido=?, correo=? WHERE id_usuario=?");
    $stmt->execute([$nombre, $apellido, $correo, $id]);
    header("Location: estudiantes.php");
    exit;
}

// Eliminar estudiante
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id_usuario=? AND tipo='Estudiante'");
    $stmt->execute([$id]);
    header("Location: estudiantes.php");
    exit;
}

// Obtener lista
$estudiantes = $pdo->query("SELECT * FROM usuarios WHERE tipo='Estudiante'")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Estudiantes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-4">👨‍🎓 Estudiantes</h2>

    <!-- Botón agregar -->
    <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#modalCrear">➕ Nuevo Estudiante</button>

    <!-- Tabla -->
    <table class="table table-striped table-bordered bg-white shadow">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Correo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($estudiantes as $e): ?>
                <tr>
                    <td><?= $e['id_usuario'] ?></td>
                    <td><?= $e['nombre'] ?></td>
                    <td><?= $e['apellido'] ?></td>
                    <td><?= $e['correo'] ?></td>
                    <td>
                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#modalEditar<?= $e['id_usuario'] ?>">✏️</button>
                        <a href="?eliminar=<?= $e['id_usuario'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar estudiante?')">🗑️</a>
                    </td>
                </tr>

                <!-- Modal Editar -->
                <div class="modal fade" id="modalEditar<?= $e['id_usuario'] ?>" tabindex="-1">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <form method="POST">
                          <div class="modal-header"><h5 class="modal-title">Editar Estudiante</h5></div>
                          <div class="modal-body">
                              <input type="hidden" name="accion" value="editar">
                              <input type="hidden" name="id" value="<?= $e['id_usuario'] ?>">
                              <div class="mb-2"><label>Nombre</label><input type="text" name="nombre" class="form-control" value="<?= $e['nombre'] ?>"></div>
                              <div class="mb-2"><label>Apellido</label><input type="text" name="apellido" class="form-control" value="<?= $e['apellido'] ?>"></div>
                              <div class="mb-2"><label>Correo</label><input type="email" name="correo" class="form-control" value="<?= $e['correo'] ?>"></div>
                          </div>
                          <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Guardar</button>
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                          </div>
                      </form>
                    </div>
                  </div>
                </div>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal Crear -->
<div class="modal fade" id="modalCrear" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
          <div class="modal-header"><h5 class="modal-title">Nuevo Estudiante</h5></div>
          <div class="modal-body">
              <input type="hidden" name="accion" value="crear">
              <div class="mb-2"><label>Nombre</label><input type="text" name="nombre" class="form-control" required></div>
              <div class="mb-2"><label>Apellido</label><input type="text" name="apellido" class="form-control" required></div>
              <div class="mb-2"><label>Correo</label><input type="email" name="correo" class="form-control" required></div>
              <div class="mb-2"><label>Contraseña</label><input type="password" name="password" class="form-control" required></div>
          </div>
          <div class="modal-footer">
              <button type="submit" class="btn btn-success">Guardar</button>
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
