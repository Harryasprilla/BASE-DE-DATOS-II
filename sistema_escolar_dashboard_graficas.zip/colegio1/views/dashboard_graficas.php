
<?php
session_start();
require_once '../includes/db.php';
if (!isset($_SESSION['usuario'])) {
    header('Location: ../login.php');
    exit;
}

$usuario = $_SESSION['usuario'];

// Datos para gráficas
$estudiantes_por_curso = $pdo->query("
    SELECT c.nombre_curso, COUNT(i.id_usuario) AS cantidad
    FROM cursos c
    LEFT JOIN inscripciones i ON c.id_curso = i.id_curso
    GROUP BY c.nombre_curso
")->fetchAll(PDO::FETCH_ASSOC);

$promedios = $pdo->query("
    SELECT c.nombre_curso, ROUND(AVG(n.nota), 2) AS promedio
    FROM notas n
    JOIN cursos c ON n.id_curso = c.id_curso
    GROUP BY c.nombre_curso
")->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Gráficas</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-4">📊 Dashboard con Gráficas</h2>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="card shadow p-3">
                <h5 class="text-center">Estudiantes por Curso</h5>
                <canvas id="graficoEstudiantes"></canvas>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow p-3">
                <h5 class="text-center">Promedio de Notas por Curso</h5>
                <canvas id="graficoPromedios"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
const ctx1 = document.getElementById('graficoEstudiantes').getContext('2d');
const chart1 = new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($estudiantes_por_curso, 'nombre_curso')) ?>,
        datasets: [{
            label: 'Estudiantes',
            data: <?= json_encode(array_column($estudiantes_por_curso, 'cantidad')) ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true }
        }
    }
});

const ctx2 = document.getElementById('graficoPromedios').getContext('2d');
const chart2 = new Chart(ctx2, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($promedios, 'nombre_curso')) ?>,
        datasets: [{
            label: 'Promedio',
            data: <?= json_encode(array_column($promedios, 'promedio')) ?>,
            backgroundColor: 'rgba(255, 206, 86, 0.6)',
            borderColor: 'rgba(255, 206, 86, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, max: 100 }
        }
    }
});
</script>
</body>
</html>
