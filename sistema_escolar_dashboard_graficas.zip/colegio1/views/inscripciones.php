<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit;
}
require_once "../includes/db.php";

$stmt = $pdo->query("SELECT * FROM vistainscripciones");
$inscripciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inscripciones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h3>Inscripciones de Estudiantes</h3>
    <table class="table table-bordered">
        <thead>
            <tr><th>ID</th><th>Nombre</th><th>Apellido</th><th>Curso</th><th>Fecha</th></tr>
        </thead>
        <tbody>
        <?php foreach ($inscripciones as $i): ?>
            <tr>
                <td><?= $i['id_inscripcion'] ?></td>
                <td><?= $i['nombre'] ?></td>
                <td><?= $i['apellido'] ?></td>
                <td><?= $i['nombre_curso'] ?></td>
                <td><?= $i['fecha_inscripcion'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="../dashboard.php" class="btn btn-secondary">Volver</a>
</div>
</body>
</html>
