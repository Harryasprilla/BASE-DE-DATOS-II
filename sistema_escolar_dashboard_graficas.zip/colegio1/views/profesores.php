<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit;
}
require_once "../includes/db.php";

$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE tipo = 'Docente'");
$stmt->execute();
$profesores = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Profesores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h3>Listado de Profesores</h3>
    <table class="table table-bordered">
        <thead>
            <tr><th>ID</th><th>Nombre</th><th>Apellido</th><th>Correo</th></tr>
        </thead>
        <tbody>
        <?php foreach ($profesores as $p): ?>
            <tr>
                <td><?= $p['id_usuario'] ?></td>
                <td><?= $p['nombre'] ?></td>
                <td><?= $p['apellido'] ?></td>
                <td><?= $p['correo'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <a href="../dashboard.php" class="btn btn-secondary">Volver</a>
</div>
</body>
</html>
