<?php
require_once 'includes/db.php';
$stmt = $pdo->query("SELECT c.nombre_curso, COUNT(*) AS cantidad 
                     FROM inscripciones i 
                     JOIN cursos c ON c.id_curso = i.id_curso 
                     GROUP BY c.id_curso");
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode([
    'cursos' => array_column($data, 'nombre_curso'),
    'cantidades' => array_column($data, 'cantidad')
]);
