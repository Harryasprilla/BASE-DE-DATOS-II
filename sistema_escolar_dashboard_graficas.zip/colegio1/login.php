
<?php
session_start();
require_once 'includes/db.php';

$mensaje = '';
$imagen_perro = file_get_contents('https://dog.ceo/api/breeds/image/random');
$imagen_url = json_decode($imagen_perro, true)['message'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = filter_input(INPUT_POST, 'correo', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!$correo || !$password) {
        $mensaje = 'Todos los campos son obligatorios.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE correo = ?");
        $stmt->execute([$correo]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$usuario) {
            $mensaje = 'Credenciales incorrectas.';
        } elseif ($usuario['estado'] === 'Bloqueado') {
            $mensaje = 'Usuario bloqueado. Contacte al administrador.';
        } elseif (!password_verify($password, $usuario['password'])) {
            $intentos = $usuario['intentos_login'] + 1;
            $estado = $intentos >= 3 ? 'Bloqueado' : 'Activo';

            $stmt = $pdo->prepare("UPDATE usuarios SET intentos_login = ?, estado = ?, ultimo_intento = NOW() WHERE id_usuario = ?");
            $stmt->execute([$intentos, $estado, $usuario['id_usuario']]);

            $mensaje = $estado === 'Bloqueado' ? 'Usuario bloqueado tras 3 intentos fallidos.' : 'Credenciales incorrectas.';
        } else {
            $stmt = $pdo->prepare("UPDATE usuarios SET intentos_login = 0 WHERE id_usuario = ?");
            $stmt->execute([$usuario['id_usuario']]);

            $_SESSION['usuario'] = $usuario;
            header('Location: views/dashboard.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Sistema Escolar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(120deg, #f6f9fc, #e0eafc);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-card {
            max-width: 400px;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .dog-img {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="card login-card">
        <img src="<?= $imagen_url ?>" class="dog-img" alt="Perro aleatorio">
        <div class="card-body">
            <h4 class="text-center mb-3">Bienvenido 👋</h4>
            <?php if ($mensaje): ?>
                <div class="alert alert-danger"><?= $mensaje ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="correo" class="form-label">Correo</label>
                    <input type="email" name="correo" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Contraseña</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Ingresar</button>
            </form>
        </div>
    </div>
</body>
</html>
