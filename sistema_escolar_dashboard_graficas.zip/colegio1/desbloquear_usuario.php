<?php
session_start();
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'Administrativo') {
    header("Location: views/dashboard.php");
    exit;
}

require_once 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_usuario'])) {
    $id = intval($_POST['id_usuario']);
    $stmt = $pdo->prepare("UPDATE usuarios SET estado = 'Activo', intentos_login = 0 WHERE id_usuario = ?");
    $stmt->execute([$id]);

    $pdo->prepare("DELETE FROM usuariosbloqueados WHERE id_usuario = ?")->execute([$id]);
}

header("Location: views/dashboard.php");
exit;
?>
