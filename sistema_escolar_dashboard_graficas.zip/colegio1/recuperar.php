
<?php
require_once 'includes/db.php';
$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = filter_input(INPUT_POST, 'correo', FILTER_SANITIZE_EMAIL);

    if ($correo) {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE correo = ?");
        $stmt->execute([$correo]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
            // Generar contraseña temporal
            $temporal = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'), 0, 8);
            $hash = password_hash($temporal, PASSWORD_DEFAULT);

            // Actualizar en BD
            $stmt = $pdo->prepare("UPDATE usuarios SET password = ?, intentos_login = 0, estado = 'Activo' WHERE id_usuario = ?");
            $stmt->execute([$hash, $usuario['id_usuario']]);

            // Mensaje simulado (en un sistema real se enviaría por email)
            $mensaje = "Nueva contraseña temporal: <strong>$temporal</strong>";
        } else {
            $mensaje = "Correo no encontrado.";
        }
    } else {
        $mensaje = "Debe ingresar un correo válido.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recuperar Contraseña</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="height: 100vh;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card shadow">
                    <div class="card-body">
                        <h4 class="text-center mb-3">Recuperar Contraseña</h4>
                        <?php if ($mensaje): ?>
                            <div class="alert alert-info"><?= $mensaje ?></div>
                        <?php endif; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label for="correo" class="form-label">Correo registrado</label>
                                <input type="email" name="correo" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Generar nueva contraseña</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="login.php">Volver al login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
